import mysql, { type Connection, type ResultSetHeader, type RowDataPacket } from "mysql2/promise";
import fs from "node:fs";
import path from "node:path";
import { getMysqlConfig } from "./db-config";

export const ESTADOS_CANDIDATURA = [
  "enviado",
  "borrador",
  "omitido",
  "error",
  "pendiente",
  "en_proceso",
] as const;

export type EstadoCandidatura = (typeof ESTADOS_CANDIDATURA)[number];

export interface CandidaturaInput {
  empresa: string;
  puesto: string;
  url?: string | null;
  portalNombre?: string | null;
  estado: EstadoCandidatura;
  motivoOmision?: string | null;
  salarioOfrecido?: string | null;
  ubicacion?: string | null;
  modalidad?: string | null;
  cvUsado?: string | null;
  notas?: string | null;
  confirmacionPantalla?: string | null;
  sesionId?: number | null;
}

export interface CandidaturaRow extends RowDataPacket {
  id: number;
  sesion_id: number | null;
  empresa: string;
  puesto: string;
  url: string | null;
  portal_id: number | null;
  portal_nombre: string | null;
  estado: EstadoCandidatura;
  motivo_omision: string | null;
  salario_ofrecido: string | null;
  ubicacion: string | null;
  modalidad: string | null;
  cv_usado: string | null;
  notas: string | null;
  confirmacion_pantalla: string | null;
  created_at: Date;
  updated_at: Date;
}

const ROOT = path.resolve(process.cwd());
const SCHEMA_PATH = path.join(ROOT, "database", "schema.sql");
const SEED_PATH = path.join(ROOT, "database", "seed.sql");

function readSql(filePath: string): string {
  return fs.readFileSync(filePath, "utf8");
}

function escId(name: string): string {
  return `\`${name.replace(/`/g, "``")}\``;
}

export async function getConnection(): Promise<Connection> {
  const config = getMysqlConfig();
  return mysql.createConnection({
    host: config.host,
    port: config.port,
    user: config.user,
    password: config.password,
    database: config.database,
    charset: "utf8mb4",
    multipleStatements: true,
  });
}

async function getServerConnection(): Promise<Connection> {
  const config = getMysqlConfig();
  return mysql.createConnection({
    host: config.host,
    port: config.port,
    user: config.user,
    password: config.password,
    charset: "utf8mb4",
    multipleStatements: true,
  });
}

async function execSqlFile(conn: Connection, filePath: string): Promise<void> {
  await conn.query(readSql(filePath));
}

export async function initDatabase(options: { force?: boolean } = {}): Promise<void> {
  const config = getMysqlConfig();
  const server = await getServerConnection();

  try {
    if (options.force) {
      await server.query(`DROP DATABASE IF EXISTS ${escId(config.database)}`);
    }
    await server.query(
      `CREATE DATABASE IF NOT EXISTS ${escId(config.database)} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
    );
    await server.changeUser({ database: config.database });
    await execSqlFile(server, SCHEMA_PATH);
    await execSqlFile(server, SEED_PATH);

    const db = await getConnection();
    try {
      await logEvento(
        db,
        "sistema",
        null,
        null,
        "Base de datos inicializada",
        { schema: "database/schema.sql", motor: "mysql" }
      );
    } finally {
      await db.end();
    }
  } finally {
    await server.end();
  }
}

export async function databaseExists(): Promise<boolean> {
  try {
    const conn = await getConnection();
    try {
      await conn.query("SELECT 1 FROM candidato LIMIT 1");
      return true;
    } finally {
      await conn.end();
    }
  } catch {
    return false;
  }
}

async function resolvePortalId(
  conn: Connection,
  portalNombre?: string | null
): Promise<number | null> {
  if (!portalNombre?.trim()) return null;
  const [rows] = await conn.query<RowDataPacket[]>(
    "SELECT id FROM portales WHERE LOWER(nombre) = LOWER(?) LIMIT 1",
    [portalNombre.trim()]
  );
  return rows[0]?.id ?? null;
}

export async function estaBloqueado(
  conn: Connection,
  empresa: string,
  url?: string | null
): Promise<{ bloqueado: boolean; motivo?: string }> {
  const empresaLower = empresa.toLowerCase();

  const [empresaRows] = await conn.query<RowDataPacket[]>(
    `SELECT motivo FROM bloqueos
     WHERE activo = 1 AND tipo = 'empresa' AND LOWER(identificador) = LOWER(?)
     LIMIT 1`,
    [empresa]
  );
  if (empresaRows[0]) {
    return { bloqueado: true, motivo: empresaRows[0].motivo as string };
  }

  if (url) {
    try {
      const host = new URL(url).hostname.toLowerCase();
      const [dominioRows] = await conn.query<RowDataPacket[]>(
        `SELECT motivo FROM bloqueos
         WHERE activo = 1 AND tipo = 'dominio' AND ? LIKE CONCAT('%', identificador, '%')
         LIMIT 1`,
        [host]
      );
      if (dominioRows[0]) {
        return { bloqueado: true, motivo: dominioRows[0].motivo as string };
      }
    } catch {
      // URL inválida
    }
  }

  if (empresaLower.includes("crossing hurdles")) {
    const [recruiterRows] = await conn.query<RowDataPacket[]>(
      `SELECT motivo FROM bloqueos
       WHERE activo = 1 AND tipo = 'reclutador' AND identificador = 'Crossing Hurdles'
       LIMIT 1`
    );
    if (recruiterRows[0]) {
      return { bloqueado: true, motivo: recruiterRows[0].motivo as string };
    }
  }

  return { bloqueado: false };
}

async function existeCandidaturaActivaPorUrl(
  conn: Connection,
  url: string
): Promise<boolean> {
  const [rows] = await conn.query<RowDataPacket[]>(
    `SELECT id FROM candidaturas
     WHERE url = ? AND estado IN ('enviado', 'borrador', 'pendiente', 'en_proceso')
     LIMIT 1`,
    [url]
  );
  return rows.length > 0;
}

export async function iniciarSesion(notas?: string): Promise<number> {
  const conn = await getConnection();
  try {
    const [result] = await conn.query<ResultSetHeader>(
      "INSERT INTO sesiones (notas) VALUES (?)",
      [notas ?? null]
    );
    const id = result.insertId;
    await logEvento(conn, "sesion", "sesiones", id, "Sesión iniciada", { notas });
    return id;
  } finally {
    await conn.end();
  }
}

export async function finalizarSesion(
  sesionId: number,
  resumen?: {
    notas?: string;
    totalEnviadas?: number;
    totalOmitidas?: number;
    totalErrores?: number;
    totalBorradores?: number;
  }
): Promise<void> {
  const conn = await getConnection();
  try {
    const [statsRows] = await conn.query<RowDataPacket[]>(
      `SELECT
         SUM(CASE WHEN estado = 'enviado' THEN 1 ELSE 0 END) AS enviadas,
         SUM(CASE WHEN estado = 'omitido' THEN 1 ELSE 0 END) AS omitidas,
         SUM(CASE WHEN estado = 'error' THEN 1 ELSE 0 END) AS errores,
         SUM(CASE WHEN estado = 'borrador' THEN 1 ELSE 0 END) AS borradores
       FROM candidaturas WHERE sesion_id = ?`,
      [sesionId]
    );
    const stats = statsRows[0] as {
      enviadas: number;
      omitidas: number;
      errores: number;
      borradores: number;
    };

    await conn.query(
      `UPDATE sesiones SET
         finalizada_at = NOW(),
         notas = COALESCE(?, notas),
         total_enviadas = COALESCE(?, ?),
         total_omitidas = COALESCE(?, ?),
         total_errores = COALESCE(?, ?),
         total_borradores = COALESCE(?, ?)
       WHERE id = ?`,
      [
        resumen?.notas ?? null,
        resumen?.totalEnviadas ?? null,
        stats.enviadas ?? 0,
        resumen?.totalOmitidas ?? null,
        stats.omitidas ?? 0,
        resumen?.totalErrores ?? null,
        stats.errores ?? 0,
        resumen?.totalBorradores ?? null,
        stats.borradores ?? 0,
        sesionId,
      ]
    );

    await logEvento(conn, "sesion", "sesiones", sesionId, "Sesión finalizada", stats);
  } finally {
    await conn.end();
  }
}

export async function registrarCandidatura(input: CandidaturaInput): Promise<{
  id: number;
  bloqueadoAutomatico: boolean;
}> {
  const conn = await getConnection();
  try {
    const bloqueo = await estaBloqueado(conn, input.empresa, input.url);
    let estado = input.estado;
    let motivoOmision = input.motivoOmision ?? null;

    if (bloqueo.bloqueado && estado !== "omitido") {
      estado = "omitido";
      motivoOmision = motivoOmision ?? `bloqueo: ${bloqueo.motivo}`;
    }

    const url = input.url?.trim() || null;
    if (url && estado !== "omitido" && estado !== "error") {
      const duplicada = await existeCandidaturaActivaPorUrl(conn, url);
      if (duplicada) {
        throw new Error(`Ya existe candidatura activa para URL: ${url}`);
      }
    }

    const portalId = await resolvePortalId(conn, input.portalNombre);

    const [result] = await conn.query<ResultSetHeader>(
      `INSERT INTO candidaturas (
         sesion_id, empresa, puesto, url, portal_id, portal_nombre,
         estado, motivo_omision, salario_ofrecido, ubicacion, modalidad,
         cv_usado, notas, confirmacion_pantalla
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        input.sesionId ?? null,
        input.empresa.trim(),
        input.puesto.trim(),
        url,
        portalId,
        input.portalNombre?.trim() || null,
        estado,
        motivoOmision,
        input.salarioOfrecido ?? null,
        input.ubicacion ?? null,
        input.modalidad ?? null,
        input.cvUsado ?? null,
        input.notas ?? null,
        input.confirmacionPantalla ?? null,
      ]
    );

    const id = result.insertId;

    await conn.query(
      `INSERT INTO candidatura_historial (candidatura_id, estado_anterior, estado_nuevo, notas)
       VALUES (?, NULL, ?, ?)`,
      [id, estado, motivoOmision]
    );

    await logEvento(conn, "candidatura", "candidaturas", id, "Candidatura registrada", {
      empresa: input.empresa,
      puesto: input.puesto,
      estado,
    });

    return { id, bloqueadoAutomatico: bloqueo.bloqueado };
  } finally {
    await conn.end();
  }
}

export async function actualizarEstadoCandidatura(
  id: number,
  estado: EstadoCandidatura,
  notas?: string
): Promise<void> {
  const conn = await getConnection();
  try {
    const [rows] = await conn.query<RowDataPacket[]>(
      "SELECT estado FROM candidaturas WHERE id = ?",
      [id]
    );
    const actual = rows[0] as { estado: EstadoCandidatura } | undefined;

    if (!actual) {
      throw new Error(`Candidatura #${id} no encontrada`);
    }

    await conn.query(
      `UPDATE candidaturas SET estado = ?, notas = COALESCE(?, notas), updated_at = NOW()
       WHERE id = ?`,
      [estado, notas ?? null, id]
    );

    await conn.query(
      `INSERT INTO candidatura_historial (candidatura_id, estado_anterior, estado_nuevo, notas)
       VALUES (?, ?, ?, ?)`,
      [id, actual.estado, estado, notas ?? null]
    );

    await logEvento(conn, "candidatura", "candidaturas", id, "Estado actualizado", {
      de: actual.estado,
      a: estado,
    });
  } finally {
    await conn.end();
  }
}

export async function listarCandidaturas(
  filtros: { estado?: EstadoCandidatura; limite?: number } = {}
): Promise<CandidaturaRow[]> {
  const conn = await getConnection();
  try {
    let sql = "SELECT * FROM candidaturas";
    const params: unknown[] = [];

    if (filtros.estado) {
      sql += " WHERE estado = ?";
      params.push(filtros.estado);
    }

    sql += " ORDER BY created_at DESC";

    if (filtros.limite) {
      sql += " LIMIT ?";
      params.push(filtros.limite);
    }

    const [rows] = await conn.query<CandidaturaRow[]>(sql, params);
    return rows;
  } finally {
    await conn.end();
  }
}

export async function obtenerEstadisticas(): Promise<Record<string, number>> {
  const conn = await getConnection();
  try {
    const [rows] = await conn.query<RowDataPacket[]>(
      "SELECT estado, COUNT(*) AS total FROM candidaturas GROUP BY estado"
    );

    const stats: Record<string, number> = { total: 0 };
    for (const row of rows) {
      stats[row.estado as string] = Number(row.total);
      stats.total += Number(row.total);
    }
    return stats;
  } finally {
    await conn.end();
  }
}

export async function registrarPerfilActualizacion(input: {
  portalNombre: string;
  camposModificados?: string[];
  notas?: string;
}): Promise<number> {
  const conn = await getConnection();
  try {
    const portalId = await resolvePortalId(conn, input.portalNombre);
    const [result] = await conn.query<ResultSetHeader>(
      `INSERT INTO perfil_actualizaciones (portal_id, portal_nombre, campos_modificados, notas)
       VALUES (?, ?, ?, ?)`,
      [
        portalId,
        input.portalNombre,
        input.camposModificados ? JSON.stringify(input.camposModificados) : null,
        input.notas ?? null,
      ]
    );

    const id = result.insertId;
    await logEvento(conn, "perfil", "perfil_actualizaciones", id, "Perfil actualizado", input);
    return id;
  } finally {
    await conn.end();
  }
}

async function logEvento(
  conn: Connection,
  tipo: string,
  entidad: string | null,
  entidadId: number | null,
  descripcion: string,
  metadata?: unknown
): Promise<void> {
  await conn.query(
    `INSERT INTO eventos (tipo, entidad, entidad_id, descripcion, metadata)
     VALUES (?, ?, ?, ?, ?)`,
    [
      tipo,
      entidad,
      entidadId,
      descripcion,
      metadata ? JSON.stringify(metadata) : null,
    ]
  );
}
