#!/usr/bin/env tsx
/**
 * CLI: npm run db -- <comando>
 * Comandos: init | sesion start|end | add | update | list | stats | perfil | help
 */
import {
  ESTADOS_CANDIDATURA,
  type EstadoCandidatura,
  getConnection,
  initDatabase,
  iniciarSesion,
  finalizarSesion,
  registrarCandidatura,
  actualizarEstadoCandidatura,
  listarCandidaturas,
  obtenerEstadisticas,
  registrarPerfilActualizacion,
} from "../lib/candidaturas-db";

function argValue(args: string[], name: string): string | undefined {
  const i = args.indexOf(name);
  if (i === -1) return undefined;
  return args[i + 1];
}

function hasFlag(args: string[], name: string): boolean {
  return args.includes(name);
}

function printHelp(): void {
  console.log(`Uso: npm run db -- <comando> [opciones]

Comandos:
  init [--force]
  sesion start [--notas "..."]
  sesion end <id> [--notas "..."]
  add --empresa "..." --puesto "..." --estado <estado> [--url "..."] [--portal "..."] [--sesion N] [--notas "..."] [--motivo "..."] [--confirmacion "..."] [--ubicacion "..."] [--modalidad "..."] [--cv "..."]
  update <id> --estado <estado> [--notas "..."] [--empresa "..."] [--puesto "..."]
  list [--estado ...] [--limit N]
  stats
  perfil --portal "..." [--campos "a,b"] [--notas "..."]
  help

Estados: ${ESTADOS_CANDIDATURA.join(", ")}`);
}

function asEstado(raw: string | undefined): EstadoCandidatura {
  if (!raw || !(ESTADOS_CANDIDATURA as readonly string[]).includes(raw)) {
    throw new Error(`Estado inválido: ${raw}. Válidos: ${ESTADOS_CANDIDATURA.join(", ")}`);
  }
  return raw as EstadoCandidatura;
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const cmd = args[0];

  if (!cmd || cmd === "help" || cmd === "--help" || cmd === "-h") {
    printHelp();
    return;
  }

  if (cmd === "init") {
    await initDatabase({ force: hasFlag(args, "--force") });
    console.log("Base de datos inicializada.");
    return;
  }

  if (cmd === "sesion") {
    const sub = args[1];
    if (sub === "start") {
      const notas = argValue(args, "--notas");
      const id = await iniciarSesion(notas);
      console.log(`Sesión iniciada #${id}`);
      return;
    }
    if (sub === "end") {
      const id = Number(args[2]);
      if (!id) throw new Error("Uso: sesion end <id>");
      await finalizarSesion(id, { notas: argValue(args, "--notas") });
      console.log(`Sesión #${id} finalizada`);
      return;
    }
    throw new Error("Uso: sesion start|end");
  }

  if (cmd === "add") {
    const empresa = argValue(args, "--empresa");
    const puesto = argValue(args, "--puesto");
    const estado = asEstado(argValue(args, "--estado"));
    if (!empresa || !puesto) throw new Error("add requiere --empresa y --puesto");

    const sesionRaw = argValue(args, "--sesion");
    const result = await registrarCandidatura({
      empresa,
      puesto,
      estado,
      url: argValue(args, "--url"),
      portalNombre: argValue(args, "--portal"),
      motivoOmision: argValue(args, "--motivo"),
      notas: argValue(args, "--notas"),
      confirmacionPantalla: argValue(args, "--confirmacion"),
      ubicacion: argValue(args, "--ubicacion"),
      modalidad: argValue(args, "--modalidad"),
      cvUsado: argValue(args, "--cv"),
      sesionId: sesionRaw ? Number(sesionRaw) : null,
    });

    const flag = result.bloqueadoAutomatico ? " (bloqueado automático → omitido)" : "";
    console.log(`Candidatura #${result.id} registrada [${estado}]${flag}`);
    return;
  }

  if (cmd === "update") {
    const id = Number(args[1]);
    if (!id) throw new Error("Uso: update <id> --estado ...");
    const estado = asEstado(argValue(args, "--estado"));
    const notas = argValue(args, "--notas");
    await actualizarEstadoCandidatura(id, estado, notas);

    const empresa = argValue(args, "--empresa");
    const puesto = argValue(args, "--puesto");
    if (empresa || puesto) {
      const conn = await getConnection();
      try {
        if (empresa) await conn.query("UPDATE candidaturas SET empresa = ? WHERE id = ?", [empresa, id]);
        if (puesto) await conn.query("UPDATE candidaturas SET puesto = ? WHERE id = ?", [puesto, id]);
      } finally {
        await conn.end();
      }
    }

    console.log(`Candidatura #${id} → ${estado}`);
    return;
  }

  if (cmd === "list") {
    const estadoRaw = argValue(args, "--estado");
    const limite = Number(argValue(args, "--limit") ?? argValue(args, "--limite") ?? "50");
    const rows = await listarCandidaturas({
      estado: estadoRaw ? asEstado(estadoRaw) : undefined,
      limite,
    });
    if (!rows.length) {
      console.log("(sin candidaturas)");
      return;
    }
    for (const r of rows) {
      console.log(
        `#${r.id} | ${r.estado} | ${r.empresa} | ${r.puesto} | ${r.portal_nombre ?? "-"} | ${r.url ?? "-"}`
      );
    }
    return;
  }

  if (cmd === "stats") {
    const stats = await obtenerEstadisticas();
    console.log(JSON.stringify(stats, null, 2));
    return;
  }

  if (cmd === "perfil") {
    const portal = argValue(args, "--portal");
    if (!portal) throw new Error("perfil requiere --portal");
    const campos = argValue(args, "--campos");
    const id = await registrarPerfilActualizacion({
      portalNombre: portal,
      camposModificados: campos ? campos.split(",").map((s) => s.trim()) : undefined,
      notas: argValue(args, "--notas"),
    });
    console.log(`Perfil actualizado #${id} en ${portal}`);
    return;
  }

  throw new Error(`Comando desconocido: ${cmd}. Usa help.`);
}

main().catch((err) => {
  console.error("Error:", err instanceof Error ? err.message : err);
  process.exit(1);
});
