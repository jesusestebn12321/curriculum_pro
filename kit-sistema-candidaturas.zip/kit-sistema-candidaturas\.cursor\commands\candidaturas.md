Postula / actualiza perfil según la skill `.cursor/skills/candidaturas-perfil-laboral/SKILL.md` y las rules de candidaturas.

Argumentos del usuario: $ARGUMENTS

1. Leer la skill completa (datos reales; no inventar).
2. Si es «ANALIZA PROPUESTA…»: email + PDF adaptado (no postular salvo que lo pida).
3. Si es postular: sesión BD → por cada URL filtrar (híbrido / stack / bloqueos) → navegador Cursor → registrar estado.
4. Entregar tabla empresa | puesto | URL | estado en español.
