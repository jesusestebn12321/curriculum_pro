-- Sistema de candidaturas (MySQL 8+ / MariaDB 10.4+)
-- Recreado a partir de lib/candidaturas-db.ts (el schema original del repo estaba vacío)

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS candidato (
  id INT PRIMARY KEY,
  nombre VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  telefono VARCHAR(64) NULL,
  ubicacion VARCHAR(255) NULL,
  linkedin VARCHAR(512) NULL,
  github VARCHAR(128) NULL,
  portfolio VARCHAR(512) NULL,
  rol VARCHAR(255) NULL,
  stack TEXT NULL,
  educacion VARCHAR(255) NULL,
  ingles VARCHAR(64) NULL,
  salario_min_usd INT NULL,
  salario_max_usd INT NULL,
  cv_ruta VARCHAR(512) NULL,
  foto_ruta VARCHAR(512) NULL,
  fecha_nacimiento DATE NULL,
  dni VARCHAR(32) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS portales (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(128) NOT NULL,
  url_base VARCHAR(512) NULL,
  metodo_login VARCHAR(64) NULL,
  notas TEXT NULL,
  UNIQUE KEY uniq_portal_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bloqueos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tipo ENUM('empresa','dominio','reclutador') NOT NULL,
  identificador VARCHAR(255) NOT NULL,
  motivo TEXT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY uniq_bloqueo (tipo, identificador)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sesiones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  notas TEXT NULL,
  iniciada_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  finalizada_at DATETIME NULL,
  total_enviadas INT NOT NULL DEFAULT 0,
  total_omitidas INT NOT NULL DEFAULT 0,
  total_errores INT NOT NULL DEFAULT 0,
  total_borradores INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS candidaturas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sesion_id INT NULL,
  empresa VARCHAR(255) NOT NULL,
  puesto VARCHAR(255) NOT NULL,
  url TEXT NULL,
  portal_id INT NULL,
  portal_nombre VARCHAR(128) NULL,
  estado ENUM('enviado','borrador','omitido','error','pendiente','en_proceso') NOT NULL,
  motivo_omision TEXT NULL,
  salario_ofrecido VARCHAR(128) NULL,
  ubicacion VARCHAR(255) NULL,
  modalidad VARCHAR(64) NULL,
  cv_usado VARCHAR(512) NULL,
  notas TEXT NULL,
  confirmacion_pantalla TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_candidaturas_estado (estado),
  KEY idx_candidaturas_url (url(255)),
  CONSTRAINT fk_cand_sesion FOREIGN KEY (sesion_id) REFERENCES sesiones(id),
  CONSTRAINT fk_cand_portal FOREIGN KEY (portal_id) REFERENCES portales(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS candidatura_historial (
  id INT AUTO_INCREMENT PRIMARY KEY,
  candidatura_id INT NOT NULL,
  estado_anterior VARCHAR(32) NULL,
  estado_nuevo VARCHAR(32) NOT NULL,
  notas TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_hist_cand FOREIGN KEY (candidatura_id) REFERENCES candidaturas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS perfil_actualizaciones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  portal_id INT NULL,
  portal_nombre VARCHAR(128) NOT NULL,
  campos_modificados TEXT NULL,
  notas TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS eventos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tipo VARCHAR(64) NOT NULL,
  entidad VARCHAR(64) NULL,
  entidad_id INT NULL,
  descripcion TEXT NULL,
  metadata JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
