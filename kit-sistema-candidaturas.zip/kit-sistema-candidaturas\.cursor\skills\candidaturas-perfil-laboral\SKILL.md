---
name: candidaturas-perfil-laboral
description: >-
  Guía postulaciones a vacantes y actualización de perfil laboral en portales
  externos (LinkedIn, Computrabajo, Get on Board, Teamtailor, Viterbit, Identia).
  Usar cuando el usuario pida postular, aplicar a vacantes, completar
  candidatura, cuestionario de selección o modificar/actualizar perfil laboral.
---

# Candidaturas y perfil laboral — procedimiento global

## Perfil del candidato (fuente de verdad)

Sustituir todos los `{{CAMPOS}}` con datos **reales** del candidato. No inventar empleos, fechas ni stacks.

| Campo | Valor |
|-------|--------|
| Nombre | `{{NOMBRE_COMPLETO}}` |
| Email | `{{EMAIL}}` |
| Teléfono | `{{TELEFONO}}` |
| Ubicación | `{{CIUDAD}}, {{PAIS}}` |
| LinkedIn | `{{LINKEDIN_URL}}` |
| GitHub | `{{GITHUB_USER}}` |
| Portfolio | `{{PORTFOLIO_URL}}` |
| Rol | `{{ROL}}` (ej. Fullstack / Software Developer, ~N años) |
| Stack base | `{{STACK}}` (solo tecnologías que sí tiene) |
| Plus móvil | `{{MOVIL}}` (ej. Flutter / Dart — o quitar si no aplica) |
| Herramientas IA (siempre en CV) | **Cursor** + **Claude** — obligatorios en Skills/Herramientas de todo CV adaptado |
| Educación | `{{EDUCACION}}` |
| Inglés | `{{INGLES}}` (ej. B2) |
| Salario ref. | **Mensual:** `{{SALARIO_MES_MIN}}–{{SALARIO_MES_MAX}}` USD/mes. **Por hora:** `{{SALARIO_HORA_MIN}}–{{SALARIO_HORA_MAX}}` USD/h. Si la vacante **tiene rango**, situarse dentro (mitad baja). Si no, usar el default. Preferir «negociable» si el portal lo permite. |
| CV | `public/cv.pdf` |
| Foto | `public/foto.png` |
| Fecha de nacimiento | `{{FECHA_NACIMIENTO}}` |
| DNI / cédula | `{{DNI}}` |
| Pasaporte | `{{PASAPORTE_O_NO}}` — si no tiene, nunca seleccionar Pasaporte; siempre DNI/Cédula |

### Credenciales de portales

| Portal | Usuario / email | Password | Notas |
|--------|-----------------|----------|--------|
| `{{PORTAL}}` | `{{EMAIL}}` | *(en chat o gestor, no commitear)* | Solo 100 % remoto si esa es la regla |

**Experiencia clave para textos:** listar aquí one-liners reales (empresa, rol, stack, URLs de producción). Ejemplo de formato:

- `{{EMPRESA_1}}` (`{{ROL_1}}`, `{{STACK_1}}`, `{{URL_1}}`) — `{{FECHAS_1}}`
- `{{EMPRESA_2}}` ...

## Stacks de CV (plantillas canónicas)

Al preparar un CV adaptado, elegir **uno** de estos perfiles backend. No mezclar ejes principales en el mismo CV salvo que la vacante lo pida. Ajustar A/B al stack **real** del amigo.

### Stack A — {{BACKEND_A}} (ej. Laravel + Django)

**Cuándo usarlo:** vacantes alineadas a ese backend.

| Bloque | Contenido (priorizar / filtrar a la vacante) |
|--------|-----------------------------------------------|
| Título | Fullstack — {{KEYWORDS_A}} |
| Backend | tecnologías reales del candidato |
| Frontend | ... |
| Datos & APIs | ... |
| Infra | Docker, Git/GitHub, Linux, ... |
| Plus móvil | si aplica |
| IA (siempre) | Cursor, Claude |

**Experiencia a destacar (orden típico):** la más relevante primero.

### Stack B — {{BACKEND_B}} (ej. .NET + Django)

**Cuándo usarlo:** vacantes alineadas a ese segundo eje.

Misma tabla. Documentar cada proyecto .NET/Python/etc. con: nombre, tipo, rol, fechas, tagline, URL, bullets CV, stack.

## Herramientas — navegador **solo dentro de Cursor**

Ver regla `.cursor/rules/navegador-en-cursor.mdc`.

1. **`@Browser` / `cursor-ide-browser` (único permitido):** navegar, snapshot, click, fill, select — todo en el panel del IDE. **Nunca** abrir Chrome/Edge/Firefox fuera de Cursor.
2. **`user-playwright` está PROHIBIDO** — abre ventana externa. Si `cursor-ide-browser` no está disponible, pedir al usuario activar @Browser; no sustituir con Playwright.
3. Si no hay pestaña: `browser_tabs` → `new` → `browser_navigate` (servidor `cursor-ide-browser`).
4. **No** usar `curl`/scripts para simular postulaciones si el portal es visual.
5. **No** pedir al usuario que abra el enlace en un navegador externo salvo bloqueo real (captcha, 2FA).

## Flujo estándar del agente

1. Abrir la URL que envíe el usuario (`@Browser` + enlace).
2. Si el enlace del email da 404, buscar el portal real (ej. `jobs.empresa.com`, Teamtailor Connect).
3. **Login:** magic link → pedir al usuario que pegue el enlace; contraseña solo si la proporcionó en el chat.
4. **Perfil:** completar/actualizar CV, headline, experiencia, skills, idiomas, foto — alineado con el CV de referencia.
5. **Vacantes:** priorizar remoto/LATAM y el stack del perfil; omitir las que ya digan Postulado/Applied/Draft enviado.
   - **Prohibido híbrido:** no postular a vacantes **híbridas** / «presencial y remoto» / hybrid. Solo **100 % remoto** (u omitir). Registrar `omitido` con motivo «híbrido / presencial y remoto».
   - **Prohibido stack fuera de perfil:** no postular si el **título** o los requisitos **obligatorios** piden un lenguaje que no está documentado. Tener un lenguaje del perfil **no alcanza** si el aviso también exige otro eje ausente. Registrar `omitido` con motivo «stack fuera de perfil».
6. **Cada postulación:** CV adjunto, respuestas ≥50 caracteres si hay mínimo, pausa **12–15 s** entre una y otra.
7. Al cerrar: listar éxitos, fallos/borradores, y qué debe hacer el usuario manualmente.

## Reglas por tipo de portal

- **Computrabajo VE:** `candidato.ve.computrabajo.com` → Postularme → formulario `/candidate/kq` si aparece → verificar postapply.
- **Get on Board:** `/jobs/{slug}/applications/new` (sin `/programming/`); trix ≥300/100 chars; salario en preguntas ~50+ chars; enviar borradores antes de crear nuevos.
- **Teamtailor:** `jobs.*.com/connect` + magic link; `jobs.*.com/jobs` para vacantes.
- **Viterbit:** cuestionario = subir CV + Enviar.
- **LinkedIn:** Easy Apply + PDF del CV; filtros remoto + solicitud sencilla si el usuario no pide “sin restricción”.
- **Identia:** datos → pruebas en iframe; CP España 5 dígitos si valida.

## Modificar perfil laboral

Mismos datos del CV. Cambios mínimos y comerciales: headline claro, experiencia con logros cuantificables, skills alineadas al puesto objetivo. Guardar y verificar con snapshot. No inventar empleos ni fechas no presentes en el CV.

## Bloqueos — escalar al usuario

Magic link, captcha, 2FA, contraseña no compartida, sesión expirada, “Error al realizar la postulación” persistente tras reintento, tests que requieren >20 min de interacción manual.

## Entrega al usuario (español)

| Empresa | Puesto | URL | Estado |
|---------|--------|-----|--------|

Estados: enviado / borrador / omitido / error / pendiente.

Indicar archivos usados y pasos manuales pendientes. No afirmar postulaciones sin confirmación en pantalla.

## Base de datos MySQL (registro persistente — **obligatorio en tiempo real**)

Motor: **MySQL**. Base: `cv_candidaturas` por defecto. Esquema: `database/schema.sql` · seed: `database/seed.sql`.

**Regla crítica:** no acumular registros al final del lote. **Cada vacante se persiste en la BD en el mismo turno**. Si falla el CLI, reintentar. Ejecutar sin esperar Run del usuario.

```bash
npm run db:init
```

### Flujo por lote

**1. Al iniciar el lote:**

```bash
npm run db -- sesion start --notas "descripción del lote"
```

**2. Por cada vacante — registro inmediato**

| Momento | Comando | Estado |
|---------|---------|--------|
| Abres la URL / empiezas el formulario | `add ... --estado en_proceso --sesion N` | `en_proceso` |
| Ya postulado, fuera de perfil, bloqueo | `add ... --estado omitido --motivo "..." --sesion N` | `omitido` |
| Formulario guardado sin enviar | `update <id> --estado borrador` | `borrador` |
| Fallo en portal (sin confirmación) | `update <id> --estado error` | `error` |
| Requiere acción manual (captcha, 2FA) | `update <id> --estado pendiente` | `pendiente` |
| Confirmación visible en pantalla | `update <id> --estado enviado --notas "..."` | `enviado` |

```bash
npm run db -- add --empresa "Empresa" --puesto "Puesto" --url "https://..." --estado en_proceso --portal "LinkedIn" --sesion 3
npm run db -- update 12 --estado enviado --notas "Easy Apply completado"
```

**3. Al cerrar el lote:**

```bash
npm run db -- sesion end <ID>
npm run db -- list
npm run db -- stats
```

## Alcance

Portales **externos** y perfil del candidato. No mezclar con código de otros proyectos salvo petición explícita.
