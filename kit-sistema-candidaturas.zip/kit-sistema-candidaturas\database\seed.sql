-- Datos iniciales: perfil, portales y bloqueos
-- Sustituir los valores del candidato por los de tu amigo.

INSERT INTO candidato (
  id, nombre, email, telefono, ubicacion, linkedin, github, portfolio,
  rol, stack, educacion, ingles, salario_min_usd, salario_max_usd,
  cv_ruta, foto_ruta, fecha_nacimiento, dni
) VALUES (
  1,
  '{{NOMBRE_COMPLETO}}',
  '{{EMAIL}}',
  '{{TELEFONO}}',
  '{{UBICACION}}',
  '{{LINKEDIN_URL}}',
  '{{GITHUB_USER}}',
  '{{PORTFOLIO_URL}}',
  '{{ROL}}',
  '{{STACK}}',
  '{{EDUCACION}}',
  '{{INGLES}}',
  NULL,
  NULL,
  'public/cv.pdf',
  'public/foto.png',
  '1990-01-01',
  '{{DNI}}'
) ON DUPLICATE KEY UPDATE
  nombre = VALUES(nombre),
  email = VALUES(email),
  telefono = VALUES(telefono),
  ubicacion = VALUES(ubicacion),
  linkedin = VALUES(linkedin),
  github = VALUES(github),
  portfolio = VALUES(portfolio),
  rol = VALUES(rol),
  stack = VALUES(stack),
  educacion = VALUES(educacion),
  ingles = VALUES(ingles),
  salario_min_usd = VALUES(salario_min_usd),
  salario_max_usd = VALUES(salario_max_usd),
  cv_ruta = VALUES(cv_ruta),
  foto_ruta = VALUES(foto_ruta),
  fecha_nacimiento = VALUES(fecha_nacimiento),
  dni = VALUES(dni);

INSERT IGNORE INTO portales (nombre, url_base, metodo_login, notas) VALUES
  ('LinkedIn', 'https://www.linkedin.com', 'oauth', 'Easy Apply'),
  ('Computrabajo VE', 'https://candidato.ve.computrabajo.com', 'password', 'Formulario /candidate/kq'),
  ('Get on Board', 'https://www.getonbrd.com', 'oauth', 'Trix ≥300 chars en carta'),
  ('Teamtailor', 'https://jobs.teamtailor.com', 'magic_link', 'Connect + jobs.*.com/jobs'),
  ('Viterbit', 'https://viterbit.com', 'formulario', 'CV + cuestionario'),
  ('Identia', 'https://identia.com', 'formulario', 'Pruebas gamificadas en iframe');

INSERT IGNORE INTO bloqueos (tipo, identificador, motivo) VALUES
  ('empresa', 'Micro1', 'Excluido por preferencia del candidato'),
  ('empresa', 'micro1', 'Excluido por preferencia del candidato'),
  ('dominio', 'micro1.ai', 'Excluido por preferencia del candidato'),
  ('dominio', 'jobs.micro1.ai', 'Excluido por preferencia del candidato'),
  ('reclutador', 'Crossing Hurdles', 'Funnel hacia Micro1 — omitir');
